#include <iostream>
#include <string>

using namespace std;

struct Jogador { 
    int id; 
    string nome; 
};

struct Node {
    Jogador dados;
    Node* next;
    Node(Jogador j) : dados(j), next(nullptr) {}
};

class ListaCircular {
    Node *head = nullptr, *tail = nullptr, *atual = nullptr;

public:
    ~ListaCircular() {
        if (!head) return;
        
        Node* curr = head;
        tail->next = nullptr;
        while (curr) {
            Node* aux = curr;
            curr = curr->next;
            delete aux;
        }
    }

    void cadastrar(int id, string nome) {
        Node* novo = new Node({id, nome});
        if (!head) { 
            head = tail = atual = novo; 
            novo->next = head; 
        } else { 
            tail->next = novo; 
            novo->next = head; 
            tail = novo; 
        }
        cout << "Cadastrado com sucesso!\n";
    }

    void remover(int id) {
        if (!head) { cout << "Lista vazia!\n"; return; }

        Node *curr = head, *prev = tail;
        do {
            if (curr->dados.id == id) {
                if (atual == curr) atual = curr->next;
                
                if (head == tail) {
                    head = tail = atual = nullptr;
                } else {
                    if (curr == head) head = head->next;
                    if (curr == tail) tail = prev;
                    prev->next = curr->next;
                }

                delete curr;
                cout << "Removido!\n";
                return;
            }
            prev = curr;
            curr = curr->next;
        } while (curr != head);

        cout << "Nao encontrado.\n";
    }

    void exibir() {
        if (!head) { cout << "Lista vazia!\n"; return; }

        cout << "\n--- Jogadores em Jogo ---\n";
        Node* p = head;
        do {
            cout << "ID: " << p->dados.id << " | Nome: " << p->dados.nome;
            if (p == atual) cout << " <- (Vez atual)";
            cout << "\n";
            p = p->next;
        } while (p != head);
    }

    void proximoTurno() {
        if (!atual) { cout << "Sem jogadores cadastrados.\n"; return; }
        cout << "Vez de: " << atual->dados.nome << "\n";
        atual = atual->next;
    }
};

int main() {
    ListaCircular jogo;
    int op = -1;

    while (op != 0) {
        cout << "\n1. Cadastrar | 2. Remover | 3. Exibir | 4. Turno | 0. Sair\nOpcao: ";
        cin >> op;

        if (op == 0) break;

        if (op == 1) {
            int id; 
            string n;
            cout << "ID: "; cin >> id; cin.ignore();
            cout << "Nome: "; getline(cin, n);
            jogo.cadastrar(id, n);
        } else if (op == 2) {
            int id; 
            cout << "ID a remover: "; cin >> id; 
            jogo.remover(id);
        } else if (op == 3) {
            jogo.exibir();
        } else if (op == 4) {
            jogo.proximoTurno();
        }
    }

    return 0;
}