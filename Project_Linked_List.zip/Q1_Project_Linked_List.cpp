#include <iostream>
#include <string>

using namespace std;

struct Animal {
    string nome, alimentacao, pais;
    int idade;
    Animal* proximo;

    Animal(string n, string a, string p, int i) 
        : nome(n), alimentacao(a), pais(p), idade(i), proximo(nullptr) {}
};

struct Habitat {
    Animal* cabeca = nullptr;
    int qtd = 0;

    ~Habitat() {
        while (cabeca) {
            Animal* aux = cabeca;
            cabeca = cabeca->proximo;
            delete aux;
        }
    }

    void cadastrar(string n, string a, string p, int i) {
        if (qtd >= 5) {
            cout << "Habitat cheio!\n";
            return;
        }
        Animal* novo = new Animal(n, a, p, i);
        novo->proximo = cabeca;
        cabeca = novo;
        qtd++;
        cout << "Cadastrado com sucesso!\n";
    }

    void listar() {
        if (!cabeca) { cout << "Nenhum animal cadastrado.\n"; return; }
        for (Animal* aux = cabeca; aux; aux = aux->proximo) {
            cout << "- " << aux->nome << " | " << aux->alimentacao 
                 << " | " << aux->pais << " | " << aux->idade << " anos\n";
        }
    }

    void buscar(string n) {
        for (Animal* aux = cabeca; aux; aux = aux->proximo) {
            if (aux->nome == n) {
                cout << "Encontrado: " << aux->nome << " (" << aux->alimentacao 
                     << ", " << aux->pais << ", " << aux->idade << " anos)\n";
                return;
            }
        }
        cout << "Animal nao encontrado.\n";
    }

    void remover(string n) {
        Animal *atual = cabeca, *ant = nullptr;
        while (atual && atual->nome != n) {
            ant = atual;
            atual = atual->proximo;
        }
        if (!atual) { cout << "Animal nao encontrado.\n"; return; }
        
        if (!ant) cabeca = atual->proximo;
        else ant->proximo = atual->proximo;
        
        delete atual;
        qtd--;
        cout << "Removido!\n";
    }
};

int main() {
    Habitat habitats[3];
    int op = -1, h;

    while (op != 0) {
        cout << "\n1. Cadastrar | 2. Listar | 3. Buscar | 4. Remover | 0. Sair\nOpcao: ";
        cin >> op;
        if (op == 0) break;
        if (op < 1 || op > 4) continue;

        cout << "Habitat (0-Aquatico, 1-Terrestre, 2-Voador): ";
        cin >> h;
        if (h < 0 || h > 2) continue;

        cin.ignore();

        if (op == 1) {
            string n, a, p; int i;
            cout << "Nome: "; getline(cin, n);
            cout << "Alimentacao: "; getline(cin, a);
            cout << "Pais: "; getline(cin, p);
            cout << "Idade: "; cin >> i;
            habitats[h].cadastrar(n, a, p, i);
        } else {
            string n;
            if (op == 2) habitats[h].listar();
            else if (op == 3) { cout << "Nome para buscar: "; getline(cin, n); habitats[h].buscar(n); }
            else if (op == 4) { cout << "Nome para remover: "; getline(cin, n); habitats[h].remover(n); }
        }
    }

    return 0;
}