#include <iostream>
#include <string>

using namespace std;

struct Comprador {
    string nome, cidade, ingresso;
    int idade;
};

struct Node {
    Comprador dados;
    Node *prev = nullptr, *next = nullptr;
    Node(Comprador c) : dados(c) {}
};

class ListaDupla {
    Node *head = nullptr, *tail = nullptr;

public:
    ~ListaDupla() {
        while (head) {
            Node* aux = head;
            head = head->next;
            delete aux;
        }
    }

    void cadastrar(Comprador c) {
        Node* novo = new Node(c);
        if (!head) head = tail = novo;
        else { 
            tail->next = novo; 
            novo->prev = tail; 
            tail = novo; 
        }
        cout << "Cadastrado com sucesso!\n";
    }

    void buscar(string nome) {
        for (Node* p = head; p; p = p->next) {
            if (p->dados.nome == nome) {
                cout << "Encontrado: " << p->dados.nome << " | " << p->dados.idade << " anos | " 
                     << p->dados.cidade << " | Show: " << p->dados.ingresso << "\n";
                return;
            }
        }
        cout << "Nao encontrado.\n";
    }

    void excluir(string nome) {
        for (Node* p = head; p; p = p->next) {
            if (p->dados.nome == nome) {
                if (p->prev) p->prev->next = p->next; else head = p->next;
                if (p->next) p->next->prev = p->prev; else tail = p->prev;
                delete p;
                cout << "Removido!\n";
                return;
            }
        }
        cout << "Nao encontrado.\n";
    }

    void listarOrdem() {
        if (!head) { cout << "Lista vazia.\n"; return; }
        cout << "\n--- Lista (Ordem de Entrada) ---\n";
        for (Node* p = head; p; p = p->next)
            cout << "- " << p->dados.nome << " | " << p->dados.ingresso << "\n";
    }

    void listarInverso() {
        if (!tail) { cout << "Lista vazia.\n"; return; }
        cout << "\n--- Lista (Ordem Inversa) ---\n";
        for (Node* p = tail; p; p = p->prev)
            cout << "- " << p->dados.nome << " | " << p->dados.ingresso << "\n";
    }
};

int main() {
    ListaDupla lista;
    int op = -1;

    while (op != 0) {
        cout << "\n1. Cadastrar | 2. Buscar | 3. Excluir | 4. Ordem | 5. Inversa | 0. Sair\nOpcao: ";
        cin >> op;
        cin.ignore();

        if (op == 0) break;

        if (op == 1) {
            Comprador c;
            cout << "Nome: "; getline(cin, c.nome);
            cout << "Idade: "; cin >> c.idade; cin.ignore();
            cout << "Cidade: "; getline(cin, c.cidade);
            cout << "Ingresso/Show: "; getline(cin, c.ingresso);
            lista.cadastrar(c);
        } else {
            string n;
            if (op == 2) { cout << "Buscar nome: "; getline(cin, n); lista.buscar(n); }
            else if (op == 3) { cout << "Excluir nome: "; getline(cin, n); lista.excluir(n); }
            else if (op == 4) lista.listarOrdem();
            else if (op == 5) lista.listarInverso();
        }
    }

    return 0;
}